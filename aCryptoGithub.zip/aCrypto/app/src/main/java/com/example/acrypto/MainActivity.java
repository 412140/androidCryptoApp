package com.example.acrypto;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.app.*;
//imports (unoptimized)


/*
* interface usage:
* type in string you want to encrypt
*
*
*
* */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //vars necessary
    TextView output;
    String input;
    Button encrypt;
    Button decrypt;
    int encType; //1 for c, 2 for s, 3 for v



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onClick(View v)
    {


    }

    public String caesar(String e)
    {
        String decStr;
        decStr= "";

        return decStr;
    }
}